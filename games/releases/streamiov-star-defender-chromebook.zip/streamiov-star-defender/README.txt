STREAMIOV — STAR DEFENDER
Version 0.1 | Lokaler Spielprototyp | Kostenlos: 0 EUR

START:
1. Python 3 mit Tkinter muss installiert sein.
2. Terminal im entpackten Ordner öffnen.
3. Starten mit: python3 game.py

STEUERUNG:
Pfeiltasten oder WASD = bewegen
Leertaste = schießen
R = Neustart nach Game Over

Eigenständiges lokales Spiel. Kein Browser-Spiel.
Keine Stream-Interaktionen oder Overlay-Abhängigkeit.
Prototyp: vor einer öffentlichen Veröffentlichung testen.
