import tkinter as tk
import random

W, H = 800, 600
root = tk.Tk()
root.title("STREAMIOV — STAR DEFENDER")
root.resizable(False, False)
c = tk.Canvas(root, width=W, height=H, bg="#050713", highlightthickness=0)
c.pack()

keys = set()
stars = [(random.randrange(W), random.randrange(H)) for _ in range(90)]
player = [W // 2, H - 65]
bullets, enemies, particles = [], [], []
score, lives, frame, running = 0, 3, 0, True
game_over = False

def key_down(e):
    keys.add(e.keysym.lower())
    if game_over and e.keysym.lower() == "r":
        restart()

def key_up(e):
    keys.discard(e.keysym.lower())

root.bind("<KeyPress>", key_down)
root.bind("<KeyRelease>", key_up)

def restart():
    global score, lives, frame, running, game_over
    score, lives, frame = 0, 3, 0
    bullets.clear()
    enemies.clear()
    particles.clear()
    player[:] = [W // 2, H - 65]
    game_over = False
    running = True
    tick()

def tick():
    global frame, score, lives, game_over
    if game_over:
        return
    frame += 1
    c.delete("all")

    for x, y in stars:
        c.create_oval(x, y, x+2, y+2, fill="#50658a", outline="")
    stars[:] = [(x, (y+2) % H) for x, y in stars]

    dx = ("right" in keys or "d" in keys) - ("left" in keys or "a" in keys)
    dy = ("down" in keys or "s" in keys) - ("up" in keys or "w" in keys)
    player[0] = max(25, min(W-25, player[0] + dx*6))
    player[1] = max(35, min(H-30, player[1] + dy*6))

    if "space" in keys and frame % 9 == 0:
        bullets.append([player[0], player[1]-22])

    if frame % max(12, 38-score//80) == 0:
        x = random.randint(30, W-30)
        enemies.append([x, -20, random.choice([1, 1, 2])])

    for b in bullets[:]:
        b[1] -= 10
        c.create_rectangle(b[0]-3, b[1]-9, b[0]+3, b[1]+9,
                           fill="#00f5ff", outline="")
        if b[1] < 0:
            bullets.remove(b)

    for en in enemies[:]:
        en[1] += 2 + min(4, score//100)
        x, y, hp = en
        c.create_polygon(x, y+14, x-15, y-10, x, y-5,
                         x+15, y-10, fill="#a855f7", outline="#e1c4ff")
        if abs(x-player[0]) < 23 and abs(y-player[1]) < 25:
            enemies.remove(en)
            lives -= 1
            if lives <= 0:
                game_over = True
        elif y > H+20:
            enemies.remove(en)
        else:
            for b in bullets[:]:
                if abs(b[0]-x) < 18 and abs(b[1]-y) < 18:
                    bullets.remove(b)
                    en[2] -= 1
                    if en[2] <= 0:
                        enemies.remove(en)
                        score += 10
                    break

    x, y = player
    c.create_polygon(x, y-24, x-20, y+19, x, y+10, x+20, y+19,
                     fill="#00eaff", outline="#c8ffff", width=2)
    c.create_text(16, 16, anchor="nw", fill="white",
                  font=("Arial", 15, "bold"),
                  text=f"STREAMIOV  |  PUNKTE: {score}  |  LEBEN: {lives}")
    c.create_text(W//2, H-12, fill="#9ba9c7",
                  font=("Arial", 10),
                  text="BEWEGEN: WASD / PFEILE     SCHIESSEN: LEERTASTE")

    if game_over:
        c.create_rectangle(150, 190, 650, 390,
                           fill="#0c1024", outline="#8b5cff", width=3)
        c.create_text(W//2, 240, fill="#00eaff",
                      font=("Arial", 30, "bold"), text="GAME OVER")
        c.create_text(W//2, 290, fill="white",
                      font=("Arial", 18), text=f"Punkte: {score}")
        c.create_text(W//2, 335, fill="#c9b6ff",
                      font=("Arial", 14), text="R drücken zum Neustart")
        return
    root.after(16, tick)

tick()
root.mainloop()
